<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>insert data</title>
</head>
<body>
        <table>
        	
<tr>
	<td>
		enter first name
	</td>
	<td>
		<input type="text" name="fname" id="fname">
	</td>
</tr>
<tr>
	<td>
		enter last name
	</td>
	<td>
		<input type="text" name="lname" id="lname">
	</td>
</tr>
<tr>
	<td>
	
	</td>
	<td>
		<input type="submit" name="save" id="save">
	</td>
</tr>

        </table>
</body>
</html>